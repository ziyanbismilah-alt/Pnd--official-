# PND Official (Android, Kotlin + Jetpack Compose)

## Cara membuat APK

### Cara 1: lewat GitHub (tanpa laptop, bisa dari HP)
1. Buat repository baru di GitHub, unggah seluruh isi folder ini (termasuk folder `.github`).
2. Buka tab **Actions** > **Build APK** > **Run workflow**. Tunggu sekitar 5 menit.
3. Unduh artifact **PND-Official-apk** (berisi `app-debug.apk`), ekstrak, lalu pasang di HP.

### Cara 2: Android Studio
1. Buka folder ini di Android Studio (Koala atau lebih baru), tunggu Gradle sync.
2. Menu **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
3. File ada di `app/build/outputs/apk/debug/app-debug.apk`.

### Memasang di HP
Buka file APK, izinkan "Instal aplikasi tidak dikenal" bila diminta, lalu pasang.
APK debug sudah bisa dipasang dan dibagikan ke anggota komunitas. Untuk Play Store, buat signing key sendiri.

## Fitur admin
- Masuk lewat **Profil > Masuk Admin**. PIN awal: `pnd2026`. **Segera ganti** di Panel Admin > Keamanan.
- Admin bisa: ganti peta (dari galeri) atau kembalikan peta asli, ubah teks profil, tambah/ubah/hapus negara, ranking militer, dan berita.
- Peta asli ada di `app/src/main/res/drawable-nodpi/pnd_map.jpg` dan tidak diubah sama sekali.

## Agar perubahan admin terlihat di HP semua anggota
Perubahan di Panel Admin tersimpan di HP admin sendiri. Supaya semua anggota ikut melihatnya:
1. Di Panel Admin, tekan **Salin JSON data saat ini**.
2. Tempel ke file JSON yang bisa dibuka publik lewat https (mis. file di GitHub, lalu pakai tombol Raw). Lihat `contoh-data-admin.json`.
3. Isi alamat file itu di **Sinkronisasi ke semua anggota** di HP admin, lalu **Simpan & sinkronkan**.
4. Anggota memasukkan URL yang sama sekali saja di HP masing-masing, atau URL bisa ditanam di kode lewat `syncUrl` bawaan di `PndRepository.kt`.
5. Untuk mengganti peta untuk semua anggota, isi `"mapUrl"` di JSON dengan alamat https gambar peta baru.

## Catatan
- Nilai ranking, ibu kota, dan deskripsi negara adalah data contoh. Ubah lewat Panel Admin.
- PIN admin hanya melindungi tampilan panel di aplikasi. Untuk keamanan penuh antar-anggota, gunakan akses edit file JSON (mis. hak tulis repo GitHub) hanya untuk admin.
