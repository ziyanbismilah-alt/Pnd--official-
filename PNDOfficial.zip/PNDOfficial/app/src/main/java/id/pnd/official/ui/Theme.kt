package id.pnd.official.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight

val PndBlue = Color(0xFF2448F6)
val PndDeep = Color(0xFF0B1B6B)
val PndSky = Color(0xFFE9EEFF)
val PndInk = Color(0xFF0E1330)
val PndBg = Color(0xFFF5F7FF)

private val PndColors = lightColorScheme(
    primary = PndBlue,
    onPrimary = Color.White,
    primaryContainer = PndSky,
    onPrimaryContainer = PndDeep,
    secondary = PndDeep,
    onSecondary = Color.White,
    secondaryContainer = PndSky,
    onSecondaryContainer = PndDeep,
    background = PndBg,
    onBackground = PndInk,
    surface = Color.White,
    onSurface = PndInk,
    surfaceVariant = PndSky,
    onSurfaceVariant = Color(0xFF47507F),
    outline = Color(0xFFB8C2F0),
    outlineVariant = Color(0xFFDCE3FF),
    surfaceContainer = Color.White,
    surfaceContainerHigh = Color.White,
    error = Color(0xFFD32F2F),
)

private val base = Typography()
private val PndTypography = base.copy(
    headlineMedium = base.headlineMedium.copy(fontWeight = FontWeight.Bold),
    headlineSmall = base.headlineSmall.copy(fontWeight = FontWeight.Bold),
    titleLarge = base.titleLarge.copy(fontWeight = FontWeight.Bold),
    titleMedium = base.titleMedium.copy(fontWeight = FontWeight.SemiBold),
)

@Composable
fun PndTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = PndColors,
        typography = PndTypography,
        content = content,
    )
}
