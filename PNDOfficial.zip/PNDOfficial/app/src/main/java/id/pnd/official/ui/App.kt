package id.pnd.official.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import id.pnd.official.R
import id.pnd.official.data.PndViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private enum class Tab(val label: String, val icon: ImageVector) {
    Home("Beranda", Icons.Filled.Home),
    Map("Peta", Icons.Filled.Place),
    Countries("Negara", Icons.AutoMirrored.Filled.List),
    Ranking("Ranking", Icons.Filled.Star),
    News("Berita", Icons.Filled.Notifications),
    Profile("Profil", Icons.Filled.Person),
}

private const val ADMIN_PAGE = -1

@Composable
fun PndApp(vm: PndViewModel = viewModel()) {
    var showSplash by rememberSaveable { mutableStateOf(true) }
    var tabIndex by rememberSaveable { mutableIntStateOf(0) }
    var adminRequested by rememberSaveable { mutableStateOf(false) }
    // Setelah proses dimatikan sistem, sesi admin hilang -> otomatis keluar dari panel.
    val adminOpen = adminRequested && vm.isAdmin

    val snackbar = remember { SnackbarHostState() }
    LaunchedEffect(vm.message) {
        vm.message?.let {
            snackbar.showSnackbar(it)
            vm.messageShown()
        }
    }

    BackHandler(enabled = adminOpen) { adminRequested = false }

    Crossfade(targetState = showSplash, animationSpec = tween(500), label = "splash") { splash ->
        if (splash) {
            SplashScreen(onFinish = { showSplash = false })
        } else {
            Scaffold(
                containerColor = PndBg,
                contentWindowInsets = WindowInsets(0, 0, 0, 0),
                snackbarHost = { SnackbarHost(snackbar) },
                bottomBar = {
                    NavigationBar(containerColor = Color.White) {
                        Tab.entries.forEachIndexed { i, tab ->
                            NavigationBarItem(
                                selected = !adminOpen && tabIndex == i,
                                onClick = {
                                    adminRequested = false
                                    tabIndex = i
                                },
                                icon = { Icon(tab.icon, contentDescription = tab.label) },
                                label = { Text(tab.label, fontSize = 11.sp, maxLines = 1) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = Color.White,
                                    selectedTextColor = PndBlue,
                                    indicatorColor = PndBlue,
                                    unselectedIconColor = Color(0xFF6B76A8),
                                    unselectedTextColor = Color(0xFF6B76A8),
                                ),
                            )
                        }
                    }
                },
            ) { padding ->
                Box(Modifier.padding(padding).fillMaxSize()) {
                    AnimatedContent(
                        targetState = if (adminOpen) ADMIN_PAGE else tabIndex,
                        transitionSpec = { fadeIn(tween(240)) togetherWith fadeOut(tween(160)) },
                        label = "page",
                    ) { page ->
                        when (page) {
                            ADMIN_PAGE -> AdminScreen(vm, onClose = { adminRequested = false })
                            0 -> HomeScreen(vm, onNavigate = { tabIndex = it })
                            1 -> MapScreen(vm)
                            2 -> CountriesScreen(vm)
                            3 -> RankingScreen(vm)
                            4 -> NewsScreen(vm)
                            else -> ProfileScreen(vm, onOpenAdmin = { adminRequested = true })
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SplashScreen(onFinish: () -> Unit) {
    val logoScale = remember { Animatable(0.7f) }
    val textAlpha = remember { Animatable(0f) }

    LaunchedEffect(Unit) {
        launch {
            logoScale.animateTo(
                1f,
                spring(dampingRatio = 0.55f, stiffness = Spring.StiffnessLow),
            )
        }
        textAlpha.animateTo(1f, tween(900))
        delay(1600)
        onFinish()
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(PndBlue, PndDeep))),
        contentAlignment = Alignment.Center,
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(32.dp),
        ) {
            Image(
                painter = painterResource(R.drawable.pnd_logo),
                contentDescription = "Logo PND",
                modifier = Modifier
                    .size(180.dp)
                    .scale(logoScale.value)
                    .clip(CircleShape),
            )
            Spacer(Modifier.height(32.dp))
            Text(
                "SELAMAT DATANG DI PND",
                color = Color.White,
                fontSize = 26.sp,
                fontWeight = FontWeight.ExtraBold,
                letterSpacing = 2.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.alpha(textAlpha.value),
            )
            Spacer(Modifier.height(6.dp))
            Text(
                "PND Official",
                color = Color.White.copy(alpha = 0.8f),
                fontSize = 15.sp,
                modifier = Modifier.alpha(textAlpha.value),
            )
            Spacer(Modifier.height(36.dp))
            Button(
                onClick = onFinish,
                colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = PndBlue),
                modifier = Modifier.alpha(textAlpha.value),
            ) {
                Text("MASUK", fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            }
        }
    }
}
