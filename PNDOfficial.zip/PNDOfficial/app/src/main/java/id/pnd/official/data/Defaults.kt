package id.pnd.official.data

/**
 * Data awal. Negara diambil dari nama-nama yang tertulis di peta PND.
 * Pemerintahan/ibu kota/deskripsi dan nilai ranking masih contoh: admin bisa mengubahnya lewat Panel Admin.
 */
object Defaults {

    const val ABOUT =
        "PND adalah komunitas dengan dunia peta sendiri. Di sini anggota bisa melihat peta dunia PND, " +
            "direktori negara, peringkat kekuatan militer, serta berita dan pengumuman terbaru dari admin."

    private fun country(name: String, gov: String, color: String) = Country(
        id = name.lowercase().replace(" ", "-"),
        name = name,
        government = gov,
        capital = "-",
        description = "Belum ada deskripsi. Admin dapat mengisinya di Panel Admin.",
        colorHex = color,
    )

    private fun rank(country: String, army: Int, navy: Int, air: Int) =
        MilitaryRank(country.lowercase().replace(" ", "-"), country, army, navy, air)

    val content = PndContent(
        about = ABOUT,
        countries = listOf(
            country("Norvaskia", "Negara", "#2200FF"),
            country("Verlandia Empire", "Kekaisaran", "#004400"),
            country("Tsuzakura", "Negara", "#FF2200"),
            country("Kekaisaran Dodo", "Kekaisaran", "#5FA88A"),
            country("Bonten", "Negara", "#8B0000"),
            country("Hasia", "Negara", "#4A5580"),
            country("Republik Zakrand", "Republik", "#5A5A5A"),
            country("Republik Azuria", "Republik", "#3399DD"),
            country("Zaixn", "Negara", "#001B4D"),
            country("Zarxus Imperialis", "Kekaisaran", "#7A2A7A"),
            country("Republik Promateria", "Republik", "#4F5A45"),
            country("Republik Frenco", "Republik", "#8A4A4A"),
            country("Republik Speravita", "Republik", "#1F2F80"),
            country("Karibia", "Negara", "#FFEE00"),
            country("Kovaria", "Negara", "#2E2323"),
            country("Kesultanan Swedsh", "Kesultanan", "#0A8A0A"),
            country("Khalifia", "Negara", "#FF9100"),
            country("Republik Runichav", "Republik", "#5A3A1A"),
            country("Batunesi", "Negara", "#FFFF00"),
            country("Republik Palembia", "Republik", "#C8B05A"),
            country("Danul Qamara", "Negara", "#10FF10"),
        ),
        ranking = listOf(
            rank("Norvaskia", 92, 85, 90),
            rank("Tsuzakura", 88, 82, 86),
            rank("Verlandia Empire", 85, 80, 78),
            rank("Bonten", 74, 78, 70),
            rank("Republik Zakrand", 76, 60, 72),
            rank("Hasia", 70, 66, 64),
            rank("Kekaisaran Dodo", 62, 70, 58),
            rank("Zaixn", 66, 52, 68),
            rank("Kovaria", 64, 40, 60),
            rank("Kesultanan Swedsh", 60, 30, 55),
        ),
        news = listOf(
            NewsItem(
                id = "welcome",
                title = "Selamat datang di PND Official",
                body = "Aplikasi resmi komunitas PND sudah aktif. Lihat peta, direktori negara, dan ranking militer di menu bawah. " +
                    "Pantau terus halaman Berita untuk pengumuman dari admin.",
                date = "08 Nov 2026",
                pinned = true,
            ),
        ),
    )
}
