package id.pnd.official.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SmallFloatingActionButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import id.pnd.official.R
import id.pnd.official.data.NewsItem
import id.pnd.official.data.PndViewModel

private val ListPadding = Modifier.padding(horizontal = 16.dp)

// ───────────────────────── 2. BERANDA ─────────────────────────

@Composable
fun HomeScreen(vm: PndViewModel, onNavigate: (Int) -> Unit) {
    val content = vm.content
    val latest = content.news.sortedByDescending { it.pinned }.take(2)

    LazyColumn(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            ScreenHeader(title = "PND Official", subtitle = "Beranda komunitas PND")
        }
        item {
            Reveal(0) {
                Row(
                    ListPadding,
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Image(
                        painter = painterResource(R.drawable.pnd_logo),
                        contentDescription = "Logo PND",
                        modifier = Modifier.size(72.dp).clip(CircleShape),
                    )
                    Column {
                        Text("Halo, warga PND!", style = MaterialTheme.typography.titleLarge)
                        Text(
                            "Jelajahi peta, negara, dan kabar terbaru komunitas.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }
        }
        item {
            Reveal(120) {
                Row(ListPadding, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    StatCard("Negara", content.countries.size.toString(), Modifier.weight(1f))
                    StatCard("Ranking", content.ranking.size.toString(), Modifier.weight(1f))
                    StatCard("Berita", content.news.size.toString(), Modifier.weight(1f))
                }
            }
        }
        item {
            Reveal(220) {
                Column(ListPadding, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Akses cepat", style = MaterialTheme.typography.titleMedium)
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        QuickCard("Peta Dunia", "Lihat & zoom peta", Modifier.weight(1f)) { onNavigate(1) }
                        QuickCard("Direktori", "Semua negara PND", Modifier.weight(1f)) { onNavigate(2) }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        QuickCard("Ranking Militer", "Kekuatan negara", Modifier.weight(1f)) { onNavigate(3) }
                        QuickCard("Profil", "Tentang komunitas", Modifier.weight(1f)) { onNavigate(5) }
                    }
                }
            }
        }
        item {
            Reveal(320) {
                Column(ListPadding, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text("Pengumuman terbaru", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                        TextButton(onClick = { onNavigate(4) }) { Text("Lihat semua") }
                    }
                    if (latest.isEmpty()) {
                        Text("Belum ada pengumuman.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    latest.forEach { NewsCard(it) }
                }
            }
        }
        item { Spacer(Modifier.height(16.dp)) }
    }
}

@Composable
private fun StatCard(label: String, value: String, modifier: Modifier = Modifier) {
    PndCard(modifier) {
        Column(Modifier.padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value, style = MaterialTheme.typography.headlineMedium, color = PndBlue)
            Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun QuickCard(title: String, subtitle: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Card(
        onClick = onClick,
        modifier = modifier,
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = PndSky),
    ) {
        Column(Modifier.padding(16.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, color = PndDeep)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

// ───────────────────────── 3. PETA DUNIA ─────────────────────────

@Composable
fun MapScreen(vm: PndViewModel) {
    var scale by remember { mutableFloatStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }
    var box by remember { mutableStateOf(IntSize.Zero) }

    fun clamp(o: Offset, s: Float): Offset {
        val maxX = box.width * (s - 1f) / 2f
        val maxY = box.height * (s - 1f) / 2f
        return Offset(o.x.coerceIn(-maxX, maxX), o.y.coerceIn(-maxY, maxY))
    }

    fun zoomTo(newScale: Float) {
        scale = newScale.coerceIn(1f, 6f)
        offset = clamp(offset, scale)
    }

    Column(Modifier.fillMaxSize()) {
        ScreenHeader(title = "Peta Dunia PND", subtitle = "Cubit untuk zoom, geser untuk menjelajah")
        Box(
            Modifier
                .weight(1f)
                .fillMaxWidth()
                .background(Color(0xFF86C7FF))
                .onSizeChanged { box = it }
                .pointerInput(Unit) {
                    detectTapGestures(onDoubleTap = {
                        scale = 1f
                        offset = Offset.Zero
                    })
                }
                .pointerInput(Unit) {
                    detectTransformGestures { _, pan, zoom, _ ->
                        val newScale = (scale * zoom).coerceIn(1f, 6f)
                        scale = newScale
                        offset = clamp(offset + pan, newScale)
                    }
                },
        ) {
            val mapModifier = Modifier
                .fillMaxSize()
                .graphicsLayer(
                    scaleX = scale,
                    scaleY = scale,
                    translationX = offset.x,
                    translationY = offset.y,
                )
            val custom = vm.customMap
            if (custom != null) {
                Image(
                    bitmap = custom,
                    contentDescription = "Peta dunia PND",
                    modifier = mapModifier,
                    contentScale = ContentScale.Fit,
                )
            } else {
                // Peta asli bawaan, ditampilkan apa adanya (tanpa crop / edit).
                Image(
                    painter = painterResource(R.drawable.pnd_map),
                    contentDescription = "Peta dunia PND",
                    modifier = mapModifier,
                    contentScale = ContentScale.Fit,
                )
            }
            Column(
                Modifier.align(Alignment.BottomEnd).padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                SmallFloatingActionButton(onClick = { zoomTo(scale * 1.5f) }, containerColor = Color.White, contentColor = PndBlue) {
                    Icon(Icons.Filled.Add, contentDescription = "Perbesar")
                }
                SmallFloatingActionButton(onClick = { zoomTo(scale / 1.5f) }, containerColor = Color.White, contentColor = PndBlue) {
                    Text("−", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                }
                SmallFloatingActionButton(
                    onClick = { scale = 1f; offset = Offset.Zero },
                    containerColor = Color.White,
                    contentColor = PndBlue,
                ) {
                    Icon(Icons.Filled.Refresh, contentDescription = "Reset zoom")
                }
            }
        }
    }
}

// ───────────────────────── 4. DIREKTORI NEGARA ─────────────────────────

@Composable
fun CountriesScreen(vm: PndViewModel) {
    var query by rememberSaveable { mutableStateOf("") }
    val countries = vm.content.countries.filter {
        query.isBlank() || it.name.contains(query, ignoreCase = true) ||
            it.government.contains(query, ignoreCase = true) || it.capital.contains(query, ignoreCase = true)
    }

    LazyColumn(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { ScreenHeader(title = "Direktori Negara", subtitle = "${vm.content.countries.size} negara terdaftar di PND") }
        item {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                placeholder = { Text("Cari negara…") },
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                singleLine = true,
                shape = RoundedCornerShape(16.dp),
                modifier = ListPadding.fillMaxWidth(),
            )
        }
        if (countries.isEmpty()) {
            item {
                Text(
                    "Negara tidak ditemukan.",
                    modifier = ListPadding,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        items(countries, key = { it.id }) { c ->
            var expanded by rememberSaveable(c.id) { mutableStateOf(false) }
            val color = parseHex(c.colorHex)
            PndCard(
                ListPadding
                    .clip(RoundedCornerShape(18.dp))
                    .clickable { expanded = !expanded }
                    .animateContentSize(),
            ) {
                Column(Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier.size(44.dp).clip(CircleShape).background(color),
                            contentAlignment = Alignment.Center,
                        ) {
                            Text(
                                c.name.firstOrNull()?.uppercase() ?: "?",
                                color = if (color.luminance() > 0.5f) Color.Black else Color.White,
                                fontWeight = FontWeight.Bold,
                            )
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(c.name, style = MaterialTheme.typography.titleMedium)
                            Text(
                                c.government,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                        Icon(
                            if (expanded) Icons.Filled.KeyboardArrowUp else Icons.Filled.KeyboardArrowDown,
                            contentDescription = null,
                            tint = PndBlue,
                        )
                    }
                    AnimatedVisibility(expanded) {
                        Column(Modifier.padding(top = 12.dp)) {
                            InfoRow("Ibu kota", c.capital)
                            InfoRow("Pemerintahan", c.government)
                            Spacer(Modifier.height(6.dp))
                            Text(c.description, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            }
        }
        item { Spacer(Modifier.height(16.dp)) }
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(Modifier.padding(vertical = 2.dp)) {
        Text(label, Modifier.width(110.dp), color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium)
        Text(value, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
    }
}

// ───────────────────────── 5. WORLD MILITARY RANKING ─────────────────────────

@Composable
fun RankingScreen(vm: PndViewModel) {
    val ranking = vm.content.ranking.sortedByDescending { it.power }

    LazyColumn(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            ScreenHeader(
                title = "World Military Ranking PND",
                subtitle = "Skor = Darat 40% · Laut 30% · Udara 30%",
            )
        }
        if (ranking.isEmpty()) {
            item { Text("Belum ada data ranking.", modifier = ListPadding, color = MaterialTheme.colorScheme.onSurfaceVariant) }
        }
        items(ranking.size, key = { ranking[it].id }) { index ->
            val r = ranking[index]
            var go by remember { mutableStateOf(false) }
            LaunchedEffect(Unit) { go = true }
            val badge = when (index) {
                0 -> Color(0xFFFFC107)
                1 -> Color(0xFFB0BEC5)
                2 -> Color(0xFFCD7F32)
                else -> PndSky
            }
            PndCard(ListPadding) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier.size(38.dp).clip(CircleShape).background(badge),
                            contentAlignment = Alignment.Center,
                        ) {
                            Text("${index + 1}", fontWeight = FontWeight.Bold, color = if (index < 3) Color.Black else PndDeep)
                        }
                        Spacer(Modifier.width(12.dp))
                        Text(r.country, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                        Column(horizontalAlignment = Alignment.End) {
                            Text("${r.power}", style = MaterialTheme.typography.headlineSmall, color = PndBlue)
                            Text("skor", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                    StatBar("Darat", r.army, go)
                    StatBar("Laut", r.navy, go)
                    StatBar("Udara", r.air, go)
                }
            }
        }
        item { Spacer(Modifier.height(16.dp)) }
    }
}

@Composable
private fun StatBar(label: String, value: Int, go: Boolean) {
    val progress by animateFloatAsState(if (go) value / 100f else 0f, tween(900), label = "bar")
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.width(52.dp), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        LinearProgressIndicator(
            progress = { progress },
            modifier = Modifier.weight(1f).height(8.dp).clip(RoundedCornerShape(4.dp)),
            color = PndBlue,
            trackColor = PndSky,
        )
        Text("$value", Modifier.width(34.dp), textAlign = TextAlign.End, style = MaterialTheme.typography.labelMedium)
    }
}

// ───────────────────────── 6. BERITA & PENGUMUMAN ─────────────────────────

@Composable
fun NewsScreen(vm: PndViewModel) {
    val news = vm.content.news.sortedByDescending { it.pinned }

    LazyColumn(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { ScreenHeader(title = "Berita & Pengumuman", subtitle = "Kabar resmi dari admin PND") }
        if (news.isEmpty()) {
            item { Text("Belum ada berita.", modifier = ListPadding, color = MaterialTheme.colorScheme.onSurfaceVariant) }
        }
        items(news, key = { it.id }) { n ->
            Box(ListPadding) { NewsCard(n) }
        }
        item { Spacer(Modifier.height(16.dp)) }
    }
}

@Composable
fun NewsCard(n: NewsItem) {
    PndCard {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (n.pinned) {
                    Text(
                        "PENTING",
                        color = Color.White,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(PndBlue)
                            .padding(horizontal = 8.dp, vertical = 3.dp),
                    )
                    Spacer(Modifier.width(8.dp))
                }
                Text(n.date, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Text(n.title, style = MaterialTheme.typography.titleMedium)
            Text(n.body, style = MaterialTheme.typography.bodyMedium)
        }
    }
}

// ───────────────────────── 7. PROFIL KOMUNITAS ─────────────────────────

@Composable
fun ProfileScreen(vm: PndViewModel, onOpenAdmin: () -> Unit) {
    var showLogin by remember { mutableStateOf(false) }

    LazyColumn(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            ScreenHeader(title = "Profil Komunitas", subtitle = "Tentang PND") {
                Spacer(Modifier.height(14.dp))
                Image(
                    painter = painterResource(R.drawable.pnd_logo),
                    contentDescription = "Logo PND",
                    modifier = Modifier.size(96.dp).clip(CircleShape),
                )
            }
        }
        item {
            Reveal(0) {
                PndCard(ListPadding) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Tentang PND", style = MaterialTheme.typography.titleMedium)
                        Text(vm.content.about, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }
        item {
            Reveal(120) {
                PndCard(ListPadding) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("Info aplikasi", style = MaterialTheme.typography.titleMedium)
                        InfoRow("Aplikasi", "PND Official")
                        InfoRow("Versi", "1.0")
                        InfoRow("Negara", "${vm.content.countries.size}")
                        InfoRow("Berita", "${vm.content.news.size}")
                    }
                }
            }
        }
        if (vm.syncUrl.isNotBlank()) {
            item {
                OutlinedButton(
                    onClick = { vm.sync() },
                    enabled = !vm.syncing,
                    modifier = ListPadding.fillMaxWidth(),
                ) {
                    Icon(Icons.Filled.Refresh, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text(if (vm.syncing) "Memperbarui…" else "Perbarui data dari server")
                }
            }
        }
        item {
            Column(ListPadding, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (vm.isAdmin) {
                    Button(onClick = onOpenAdmin, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Filled.Lock, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("Buka Panel Admin")
                    }
                    TextButton(onClick = { vm.logout() }, modifier = Modifier.fillMaxWidth()) { Text("Keluar dari mode admin") }
                } else {
                    OutlinedButton(onClick = { showLogin = true }, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Filled.Lock, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("Masuk Admin")
                    }
                }
            }
        }
        item { Spacer(Modifier.height(16.dp)) }
    }

    if (showLogin) {
        LoginDialog(
            onDismiss = { showLogin = false },
            onSubmit = { pin ->
                val ok = vm.login(pin)
                if (ok) {
                    showLogin = false
                    onOpenAdmin()
                }
                ok
            },
        )
    }
}

@Composable
private fun LoginDialog(onDismiss: () -> Unit, onSubmit: (String) -> Boolean) {
    var pin by remember { mutableStateOf("") }
    var wrong by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Masuk Admin") },
        text = {
            OutlinedTextField(
                value = pin,
                onValueChange = { pin = it; wrong = false },
                label = { Text("PIN admin") },
                singleLine = true,
                isError = wrong,
                supportingText = { if (wrong) Text("PIN salah") },
                visualTransformation = PasswordVisualTransformation(),
            )
        },
        confirmButton = { TextButton(onClick = { wrong = !onSubmit(pin) }) { Text("Masuk") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } },
    )
}
