package id.pnd.official.data

import org.json.JSONArray
import org.json.JSONObject

data class Country(
    val id: String,
    val name: String,
    val government: String,
    val capital: String,
    val description: String,
    val colorHex: String,
)

data class MilitaryRank(
    val id: String,
    val country: String,
    val army: Int,
    val navy: Int,
    val air: Int,
) {
    /** Skor gabungan 0..100: darat 40%, laut 30%, udara 30%. */
    val power: Int get() = (army * 4 + navy * 3 + air * 3) / 10
}

data class NewsItem(
    val id: String,
    val title: String,
    val body: String,
    val date: String,
    val pinned: Boolean,
)

data class PndContent(
    val about: String,
    val countries: List<Country>,
    val ranking: List<MilitaryRank>,
    val news: List<NewsItem>,
    /** URL gambar peta (https). Kosong = tidak mengganti peta. Dipakai saat sinkronisasi. */
    val mapUrl: String = "",
)

/** Konversi PndContent <-> JSON. Format yang sama dipakai file penyimpanan lokal dan file sinkronisasi admin. */
object ContentJson {

    fun toJson(c: PndContent): String {
        val o = JSONObject()
        o.put("about", c.about)
        o.put("mapUrl", c.mapUrl)
        o.put("countries", JSONArray().also { arr ->
            c.countries.forEach {
                arr.put(JSONObject().apply {
                    put("id", it.id); put("name", it.name); put("government", it.government)
                    put("capital", it.capital); put("description", it.description); put("color", it.colorHex)
                })
            }
        })
        o.put("ranking", JSONArray().also { arr ->
            c.ranking.forEach {
                arr.put(JSONObject().apply {
                    put("id", it.id); put("country", it.country)
                    put("army", it.army); put("navy", it.navy); put("air", it.air)
                })
            }
        })
        o.put("news", JSONArray().also { arr ->
            c.news.forEach {
                arr.put(JSONObject().apply {
                    put("id", it.id); put("title", it.title); put("body", it.body)
                    put("date", it.date); put("pinned", it.pinned)
                })
            }
        })
        return o.toString(2)
    }

    fun fromJson(text: String): PndContent {
        val o = JSONObject(text)
        val countries = o.optJSONArray("countries") ?: JSONArray()
        val ranking = o.optJSONArray("ranking") ?: JSONArray()
        val news = o.optJSONArray("news") ?: JSONArray()
        return PndContent(
            about = o.optString("about", Defaults.ABOUT),
            mapUrl = o.optString("mapUrl", ""),
            countries = (0 until countries.length()).map { i ->
                countries.getJSONObject(i).let {
                    Country(
                        id = it.optString("id", "c$i"),
                        name = it.optString("name"),
                        government = it.optString("government", "-"),
                        capital = it.optString("capital", "-"),
                        description = it.optString("description", ""),
                        colorHex = it.optString("color", "#2448F6"),
                    )
                }
            },
            ranking = (0 until ranking.length()).map { i ->
                ranking.getJSONObject(i).let {
                    MilitaryRank(
                        id = it.optString("id", "r$i"),
                        country = it.optString("country"),
                        army = it.optInt("army", 0).coerceIn(0, 100),
                        navy = it.optInt("navy", 0).coerceIn(0, 100),
                        air = it.optInt("air", 0).coerceIn(0, 100),
                    )
                }
            },
            news = (0 until news.length()).map { i ->
                news.getJSONObject(i).let {
                    NewsItem(
                        id = it.optString("id", "n$i"),
                        title = it.optString("title"),
                        body = it.optString("body"),
                        date = it.optString("date"),
                        pinned = it.optBoolean("pinned", false),
                    )
                }
            },
        )
    }
}
