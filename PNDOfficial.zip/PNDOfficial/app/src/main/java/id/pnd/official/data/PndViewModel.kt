package id.pnd.official.data

import android.app.Application
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class PndViewModel(app: Application) : AndroidViewModel(app) {

    private val repo = PndRepository(app)

    var content by mutableStateOf(repo.loadContent())
        private set

    /** null = pakai peta asli bawaan aplikasi (res/drawable-nodpi/pnd_map.jpg). */
    var customMap by mutableStateOf<ImageBitmap?>(repo.loadCustomMap()?.asImageBitmap())
        private set

    var isAdmin by mutableStateOf(false)
        private set

    var syncUrl by mutableStateOf(repo.syncUrl)
        private set

    var syncing by mutableStateOf(false)
        private set

    /** Pesan singkat untuk Snackbar; dikosongkan lewat [messageShown]. */
    var message by mutableStateOf<String?>(null)
        private set

    init {
        if (syncUrl.isNotBlank()) sync()
    }

    fun messageShown() { message = null }

    // ---- Admin ----

    fun login(pin: String): Boolean {
        val ok = pin == repo.pin
        isAdmin = ok
        return ok
    }

    fun logout() { isAdmin = false }

    fun changePin(newPin: String): Boolean {
        if (newPin.length < 4) {
            message = "PIN minimal 4 karakter"
            return false
        }
        repo.pin = newPin
        message = "PIN admin berhasil diganti"
        return true
    }

    // ---- Konten ----

    fun update(transform: (PndContent) -> PndContent) {
        content = transform(content)
        repo.saveContent(content)
    }

    // ---- Peta ----

    fun setMapFromUri(uri: Uri) {
        viewModelScope.launch {
            val ok = withContext(Dispatchers.IO) { repo.saveCustomMap(uri) }
            if (ok) {
                customMap = withContext(Dispatchers.IO) { repo.loadCustomMap() }?.asImageBitmap()
                message = "Peta berhasil diganti"
            } else {
                message = "Gagal: file bukan gambar yang valid"
            }
        }
    }

    fun resetMap() {
        repo.clearCustomMap()
        customMap = null
        message = "Peta dikembalikan ke peta asli"
    }

    // ---- Sinkronisasi ----

    fun saveSyncUrlAndSync(url: String) {
        repo.syncUrl = url
        syncUrl = repo.syncUrl
        if (syncUrl.isBlank()) {
            message = "Sinkronisasi dimatikan"
        } else {
            sync()
        }
    }

    fun sync() {
        if (syncing || syncUrl.isBlank()) return
        syncing = true
        viewModelScope.launch {
            val result = withContext(Dispatchers.IO) { repo.sync(syncUrl) }
            result.onSuccess {
                content = it
                customMap = withContext(Dispatchers.IO) { repo.loadCustomMap() }?.asImageBitmap()
                message = "Data terbaru berhasil diperbarui"
            }.onFailure {
                message = "Sinkronisasi gagal: ${it.message ?: "periksa koneksi/URL"}"
            }
            syncing = false
        }
    }
}
