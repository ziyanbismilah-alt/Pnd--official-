package id.pnd.official.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import id.pnd.official.data.ContentJson
import id.pnd.official.data.Country
import id.pnd.official.data.MilitaryRank
import id.pnd.official.data.NewsItem
import id.pnd.official.data.PndViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

/** Dialog yang sedang terbuka di panel admin. */
private sealed interface Dlg {
    data class EditCountry(val item: Country?) : Dlg
    data class EditRank(val item: MilitaryRank?) : Dlg
    data class EditNews(val item: NewsItem?) : Dlg
    data object EditAbout : Dlg
    data object EditPin : Dlg
    data class Confirm(val text: String, val action: () -> Unit) : Dlg
}

private fun newId() = UUID.randomUUID().toString()
private fun today(): String = SimpleDateFormat("dd MMM yyyy", Locale("id", "ID")).format(Date())

@Composable
fun AdminScreen(vm: PndViewModel, onClose: () -> Unit) {
    var dialog by remember { mutableStateOf<Dlg?>(null) }
    var url by remember { mutableStateOf(vm.syncUrl) }
    val clipboard = LocalClipboardManager.current
    val content = vm.content

    val pickMap = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) vm.setMapFromUri(uri)
    }

    LazyColumn(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            ScreenHeader(title = "Panel Admin", subtitle = "Ubah peta, negara, ranking, dan berita") {
                TextButton(onClick = onClose) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack,contentDescription = null, tint = androidx.compose.ui.graphics.Color.White)
                    Spacer(Modifier.width(6.dp))
                    Text("Kembali", color = androidx.compose.ui.graphics.Color.White)
                }
            }
        }

        // ── Peta ──
        item {
            AdminSection("Peta dunia") {
                Text(
                    if (vm.customMap == null) "Saat ini: peta asli PND" else "Saat ini: peta kustom dari admin",
                    style = MaterialTheme.typography.bodyMedium,
                )
                Button(onClick = { pickMap.launch("image/*") }, modifier = Modifier.fillMaxWidth()) {
                    Text("Ganti peta dari galeri")
                }
                OutlinedButton(
                    onClick = { dialog = Dlg.Confirm("Kembalikan ke peta asli PND?") { vm.resetMap() } },
                    enabled = vm.customMap != null,
                    modifier = Modifier.fillMaxWidth(),
                ) { Text("Kembalikan peta asli") }
            }
        }

        // ── Profil ──
        item {
            AdminSection("Profil komunitas") {
                Text(content.about, style = MaterialTheme.typography.bodyMedium, maxLines = 3)
                OutlinedButton(onClick = { dialog = Dlg.EditAbout }, modifier = Modifier.fillMaxWidth()) {
                    Text("Ubah teks profil")
                }
            }
        }

        // ── Negara ──
        item {
            AdminSection("Negara (${content.countries.size})") {
                content.countries.forEach { c ->
                    AdminRow(
                        title = c.name,
                        subtitle = "${c.government} · ibu kota ${c.capital}",
                        onEdit = { dialog = Dlg.EditCountry(c) },
                        onDelete = {
                            dialog = Dlg.Confirm("Hapus negara ${c.name}?") {
                                vm.update { it.copy(countries = it.countries.filterNot { x -> x.id == c.id }) }
                            }
                        },
                    )
                }
                OutlinedButton(onClick = { dialog = Dlg.EditCountry(null) }, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Filled.Add, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text("Tambah negara")
                }
            }
        }

        // ── Ranking ──
        item {
            AdminSection("World Military Ranking (${content.ranking.size})") {
                content.ranking.sortedByDescending { it.power }.forEach { r ->
                    AdminRow(
                        title = r.country,
                        subtitle = "Skor ${r.power} · Darat ${r.army} · Laut ${r.navy} · Udara ${r.air}",
                        onEdit = { dialog = Dlg.EditRank(r) },
                        onDelete = {
                            dialog = Dlg.Confirm("Hapus ${r.country} dari ranking?") {
                                vm.update { it.copy(ranking = it.ranking.filterNot { x -> x.id == r.id }) }
                            }
                        },
                    )
                }
                OutlinedButton(onClick = { dialog = Dlg.EditRank(null) }, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Filled.Add, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text("Tambah ke ranking")
                }
            }
        }

        // ── Berita ──
        item {
            AdminSection("Berita & pengumuman (${content.news.size})") {
                content.news.forEach { n ->
                    AdminRow(
                        title = (if (n.pinned) "★ " else "") + n.title,
                        subtitle = n.date,
                        onEdit = { dialog = Dlg.EditNews(n) },
                        onDelete = {
                            dialog = Dlg.Confirm("Hapus berita \"${n.title}\"?") {
                                vm.update { it.copy(news = it.news.filterNot { x -> x.id == n.id }) }
                            }
                        },
                    )
                }
                OutlinedButton(onClick = { dialog = Dlg.EditNews(null) }, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Filled.Add, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text("Tambah berita")
                }
            }
        }

        // ── Sinkronisasi ──
        item {
            AdminSection("Sinkronisasi ke semua anggota") {
                Text(
                    "Perubahan di atas tersimpan di perangkat ini. Agar semua anggota ikut melihatnya, " +
                        "taruh data di file JSON publik (https) lalu isi alamatnya di sini. " +
                        "Aplikasi anggota akan mengambil data itu setiap dibuka.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                OutlinedTextField(
                    value = url,
                    onValueChange = { url = it },
                    label = { Text("URL file JSON (https://…)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                Button(
                    onClick = { vm.saveSyncUrlAndSync(url) },
                    enabled = !vm.syncing,
                    modifier = Modifier.fillMaxWidth(),
                ) { Text(if (vm.syncing) "Memuat…" else "Simpan & sinkronkan") }
                OutlinedButton(
                    onClick = { clipboard.setText(AnnotatedString(ContentJson.toJson(content))) },
                    modifier = Modifier.fillMaxWidth(),
                ) { Text("Salin JSON data saat ini") }
            }
        }

        // ── Keamanan ──
        item {
            AdminSection("Keamanan") {
                OutlinedButton(onClick = { dialog = Dlg.EditPin }, modifier = Modifier.fillMaxWidth()) {
                    Text("Ganti PIN admin")
                }
                TextButton(
                    onClick = {
                        vm.logout()
                        onClose()
                    },
                    modifier = Modifier.fillMaxWidth(),
                ) { Text("Keluar dari mode admin") }
            }
        }
        item { Spacer(Modifier.height(16.dp)) }
    }

    // ───── Dialog ─────
    when (val d = dialog) {
        null -> Unit

        is Dlg.EditCountry -> {
            val c = d.item
            FieldsDialog(
                title = if (c == null) "Tambah negara" else "Ubah negara",
                labels = listOf("Nama negara", "Pemerintahan", "Ibu kota", "Warna di peta (hex, mis. #FF2200)", "Deskripsi"),
                initial = listOf(
                    c?.name ?: "", c?.government ?: "", c?.capital ?: "",
                    c?.colorHex ?: "#2448F6", c?.description ?: "",
                ),
                multiline = setOf(4),
                onDismiss = { dialog = null },
                onSave = { v ->
                    if (v[0].isNotBlank()) {
                        val item = Country(
                            id = c?.id ?: newId(),
                            name = v[0].trim(),
                            government = v[1].trim().ifBlank { "-" },
                            capital = v[2].trim().ifBlank { "-" },
                            colorHex = v[3].trim().ifBlank { "#2448F6" },
                            description = v[4].trim(),
                        )
                        vm.update { cur ->
                            cur.copy(
                                countries = if (c == null) cur.countries + item
                                else cur.countries.map { if (it.id == c.id) item else it },
                            )
                        }
                        dialog = null
                    }
                },
            )
        }

        is Dlg.EditRank -> {
            val r = d.item
            FieldsDialog(
                title = if (r == null) "Tambah ranking" else "Ubah ranking",
                labels = listOf("Nama negara", "Darat (0–100)", "Laut (0–100)", "Udara (0–100)"),
                initial = listOf(r?.country ?: "", (r?.army ?: 50).toString(), (r?.navy ?: 50).toString(), (r?.air ?: 50).toString()),
                onDismiss = { dialog = null },
                onSave = { v ->
                    if (v[0].isNotBlank()) {
                        val item = MilitaryRank(
                            id = r?.id ?: newId(),
                            country = v[0].trim(),
                            army = (v[1].trim().toIntOrNull() ?: 0).coerceIn(0, 100),
                            navy = (v[2].trim().toIntOrNull() ?: 0).coerceIn(0, 100),
                            air = (v[3].trim().toIntOrNull() ?: 0).coerceIn(0, 100),
                        )
                        vm.update { cur ->
                            cur.copy(
                                ranking = if (r == null) cur.ranking + item
                                else cur.ranking.map { if (it.id == r.id) item else it },
                            )
                        }
                        dialog = null
                    }
                },
            )
        }

        is Dlg.EditNews -> {
            val n = d.item
            FieldsDialog(
                title = if (n == null) "Tambah berita" else "Ubah berita",
                labels = listOf("Judul", "Isi", "Tanggal", "Tandai PENTING? (ya / tidak)"),
                initial = listOf(n?.title ?: "", n?.body ?: "", n?.date ?: today(), if (n?.pinned == true) "ya" else "tidak"),
                multiline = setOf(1),
                onDismiss = { dialog = null },
                onSave = { v ->
                    if (v[0].isNotBlank()) {
                        val item = NewsItem(
                            id = n?.id ?: newId(),
                            title = v[0].trim(),
                            body = v[1].trim(),
                            date = v[2].trim().ifBlank { today() },
                            pinned = v[3].trim().lowercase() in setOf("ya", "y", "yes", "true"),
                        )
                        vm.update { cur ->
                            cur.copy(
                                news = if (n == null) listOf(item) + cur.news
                                else cur.news.map { if (it.id == n.id) item else it },
                            )
                        }
                        dialog = null
                    }
                },
            )
        }

        Dlg.EditAbout -> FieldsDialog(
            title = "Ubah teks profil",
            labels = listOf("Tentang PND"),
            initial = listOf(content.about),
            multiline = setOf(0),
            onDismiss = { dialog = null },
            onSave = { v ->
                vm.update { it.copy(about = v[0].trim()) }
                dialog = null
            },
        )

        Dlg.EditPin -> FieldsDialog(
            title = "Ganti PIN admin",
            labels = listOf("PIN baru (minimal 4 karakter)"),
            initial = listOf(""),
            onDismiss = { dialog = null },
            onSave = { v ->
                vm.changePin(v[0].trim())
                dialog = null
            },
        )

        is Dlg.Confirm -> AlertDialog(
            onDismissRequest = { dialog = null },
            title = { Text("Konfirmasi") },
            text = { Text(d.text) },
            confirmButton = {
                TextButton(onClick = {
                    d.action()
                    dialog = null
                }) { Text("Ya") }
            },
            dismissButton = { TextButton(onClick = { dialog = null }) { Text("Batal") } },
        )
    }
}

@Composable
private fun AdminSection(title: String, content: @Composable () -> Unit) {
    PndCard(Modifier.padding(horizontal = 16.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, color = PndDeep)
            content()
        }
    }
}

@Composable
private fun AdminRow(title: String, subtitle: String, onEdit: () -> Unit, onDelete: () -> Unit) {
    Column {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.bodyLarge, maxLines = 1)
                Text(
                    subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                )
            }
            IconButton(onClick = onEdit) { Icon(Icons.Filled.Edit, contentDescription = "Ubah", tint = PndBlue) }
            IconButton(onClick = onDelete) {
                Icon(Icons.Filled.Delete, contentDescription = "Hapus", tint = MaterialTheme.colorScheme.error)
            }
        }
        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
    }
}
