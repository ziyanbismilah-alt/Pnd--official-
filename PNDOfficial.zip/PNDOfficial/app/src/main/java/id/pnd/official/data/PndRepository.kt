package id.pnd.official.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/** Penyimpanan lokal (file internal + SharedPreferences) dan sinkronisasi dari URL admin. */
class PndRepository(private val context: Context) {

    private val prefs = context.getSharedPreferences("pnd_official", Context.MODE_PRIVATE)
    private val contentFile = File(context.filesDir, "content.json")
    private val mapFile = File(context.filesDir, "custom_map.img")

    var pin: String
        get() = prefs.getString("pin", DEFAULT_PIN) ?: DEFAULT_PIN
        set(value) = prefs.edit().putString("pin", value).apply()

    var syncUrl: String
        get() = prefs.getString("sync_url", null) ?: DEFAULT_SYNC_URL
        set(value) = prefs.edit().putString("sync_url", value.trim()).apply()

    fun loadContent(): PndContent = try {
        if (contentFile.exists()) ContentJson.fromJson(contentFile.readText()) else Defaults.content
    } catch (e: Exception) {
        Defaults.content
    }

    fun saveContent(content: PndContent) {
        contentFile.writeText(ContentJson.toJson(content))
    }

    // ---- Peta ----

    fun loadCustomMap(): Bitmap? = if (mapFile.exists()) decodeSampled(mapFile) else null

    /** Menyalin gambar pilihan admin. Mengembalikan false bila bukan gambar valid. */
    fun saveCustomMap(uri: Uri): Boolean {
        val tmp = File(context.filesDir, "custom_map.tmp")
        return try {
            context.contentResolver.openInputStream(uri)?.use { input ->
                tmp.outputStream().use { input.copyTo(it) }
            } ?: return false
            commitMap(tmp)
        } catch (e: Exception) {
            tmp.delete()
            false
        }
    }

    fun clearCustomMap() {
        mapFile.delete()
    }

    private fun commitMap(tmp: File): Boolean {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(tmp.path, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) {
            tmp.delete()
            return false
        }
        mapFile.delete()
        return tmp.renameTo(mapFile)
    }

    private fun decodeSampled(file: File, maxDim: Int = 2400): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.path, bounds)
        if (bounds.outWidth <= 0) return null
        var sample = 1
        while (bounds.outWidth / sample > maxDim || bounds.outHeight / sample > maxDim) sample *= 2
        return BitmapFactory.decodeFile(file.path, BitmapFactory.Options().apply { inSampleSize = sample })
    }

    // ---- Sinkronisasi ----

    /**
     * Mengunduh file JSON dari URL https milik admin (mis. file di GitHub/Drive publik).
     * Bila JSON memuat "mapUrl", gambar peta ikut diunduh dan menggantikan peta lokal.
     * Dipanggil dari thread background.
     */
    fun sync(url: String): Result<PndContent> = runCatching {
        require(url.startsWith("https://")) { "URL harus diawali https://" }
        val remote = ContentJson.fromJson(download(url).toString(Charsets.UTF_8))
        if (remote.mapUrl.startsWith("https://")) {
            val tmp = File(context.filesDir, "custom_map.tmp")
            tmp.writeBytes(download(remote.mapUrl))
            check(commitMap(tmp)) { "Gambar peta dari mapUrl tidak valid" }
        }
        saveContent(remote)
        remote
    }

    private fun download(url: String): ByteArray {
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.connectTimeout = 15_000
        conn.readTimeout = 20_000
        conn.instanceFollowRedirects = true
        try {
            check(conn.responseCode in 200..299) { "Server membalas ${conn.responseCode}" }
            return conn.inputStream.use { it.readBytes() }
        } finally {
            conn.disconnect()
        }
    }

    companion object {
        /** PIN awal admin. WAJIB diganti lewat Panel Admin > Keamanan. */
        const val DEFAULT_PIN = "pnd2026"

        /**
         * Isi dengan URL https file JSON data PND (lihat contoh-data-admin.json) sebelum build,
         * supaya semua anggota otomatis menerima data/peta terbaru tanpa mengisi apa pun.
         */
        const val DEFAULT_SYNC_URL = ""
    }
}
